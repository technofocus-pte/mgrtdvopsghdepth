﻿namespace TailSpin.SpaceGame.Web.Models
{
    public class ProfileViewModel
    {
        // The player profile.
        public Profile Profile;
        // The player's rank according to the active filter.
        public string Rank;
    }
}