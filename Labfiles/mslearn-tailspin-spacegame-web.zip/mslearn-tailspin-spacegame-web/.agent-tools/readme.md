This folder contains scripts used in the "Host your own build agent in Azure Pipelines"
training module